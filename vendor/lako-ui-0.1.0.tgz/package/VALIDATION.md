# 验证记录

日期：2026-09-26。

## 已完成

- `@lako/ui` 和 `samryetha-ui-commons` 类型检查、ESM 与声明构建通过。
- 14 项 Node 测试通过：旧入口兼容、导出文件存在、SSR 字段标签与说明关联、加载按钮、复选框 mixed/ref/受控状态、列表和紧凑单选的标签选择与禁用行为、原生表单提交及重置、弹窗 Esc 关闭与焦点返回。
- 主论坛、Lako Web、Tasks 和 i18n 的类型检查与生产构建通过。
- 组件展示页生产构建通过；在内置浏览器检查了浅色渲染与窄视口，未发现横向溢出。
- 两套实际 tarball 在仓库以外的空项目安装成功，Node ESM/SSR 导入、TypeScript NodeNext 解析与 CSS 子路径解析通过。
- tarball 包含声明、JS、CSS、README 与 LICENSE，未包含环境文件或展示页构建产物。
- 选择控件重构：14px 透明轮廓、1px 边框、独立 SVG 勾/横线/圆点；紧凑单选改为文字与细下划线。没有新增颜色 token、阴影、渐变、填充胶囊或选择动画。
- 在 `/selection-preview.html` 实测浅色与深色渲染、hover 后背景仍透明、单选方向键切换和跳过禁用项、Space 切换半选复选框、1px 键盘焦点轮廓。主展示页未改布局；与改动前 CSS 对照，非选择控件规则保持一致。

## 尚未完成

- 早期主展示页的自动化点击未生效，搜索、页签键盘及完整浏览器流程仍未全部验证。此次独立选择控件预览中的点击和键盘已实测；这不代表其它控件的浏览器验证已完成。
- 尚未发布到 npm / registry；最终 scope/name 与 registry 可见性待实际发包时确定。GitHub 独立仓库信息见 README。

## 已知构建提示

展示页 Vite 构建提示客户端 bundle 不保留 `use client`，该展示页本身不使用 RSC；库使用 tsc 输出，发布入口保留此指令，Lako Next 构建通过。主论坛还有既有 Vite `__dirname` 配置提示。
